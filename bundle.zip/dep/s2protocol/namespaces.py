### Namespace IDs for attributes
BLIZZARD = 999
